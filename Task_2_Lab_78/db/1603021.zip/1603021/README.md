# Database Name:          test_lab7.sql
# Password (if needed):   1603021
